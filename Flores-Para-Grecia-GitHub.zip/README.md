# 🌻 Flores para Grecia

Página web interactiva hecha con HTML, CSS y JavaScript.

## Qué incluye

- Flores amarillas pequeñas por toda la pantalla.
- Flores con animación suave.
- Pétalos cayendo.
- Nombre "Grecia" en el centro.
- Al tocar una flor aparece una dedicatoria.
- Diseño adaptable a celular y computadora.
- No necesita servidor ni librerías externas.

## Publicar con GitHub Pages

1. Crea un repositorio en GitHub, por ejemplo `flores-para-grecia`.
2. Sube `index.html`, `estilos.css` y `script.js`.
3. En el repositorio entra a **Settings → Pages**.
4. En "Build and deployment", selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`.
6. Guarda los cambios.
7. GitHub generará una dirección parecida a:

   `https://TU-USUARIO.github.io/flores-para-grecia/`

Comparte esa dirección para que la otra persona pueda abrir la página desde su navegador.
