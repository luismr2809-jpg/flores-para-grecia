const flores = document.getElementById("flores");
const petalos = document.getElementById("petalos");
const modal = document.getElementById("modal");
const dedicatoria = document.getElementById("dedicatoria");
const cerrar = document.getElementById("cerrar");

const mensajes = [
  "Grecia, que nunca te falten razones para sonreír y momentos que iluminen tus días. 💛",
  "Estas flores amarillas son un pequeño detalle para recordarte lo especial que eres. 🌻",
  "Así como estas flores buscan la luz, deseo que tú siempre encuentres motivos para ser feliz. ✨",
  "Un pequeño jardín de flores amarillas para una persona muy especial. 💛",
  "Que cada flor que encuentres aquí te recuerde que alguien quiso regalarte una sonrisa. 🌼",
  "Grecia, este pequeño detalle fue hecho pensando en ti. Espero que te guste. 💛"
];

const tiposDeFlor = ["🌻", "🌼", "🌻", "🌼", "💛"];
const cantidadFlores = 44;

function mostrarDedicatoria() {
  const indice = Math.floor(Math.random() * mensajes.length);
  dedicatoria.textContent = mensajes[indice];
  modal.classList.add("mostrar");
}

for (let i = 0; i < cantidadFlores; i++) {
  const flor = document.createElement("button");
  flor.className = "flor";
  flor.type = "button";
  flor.textContent = tiposDeFlor[Math.floor(Math.random() * tiposDeFlor.length)];

  flor.style.left = `${2 + Math.random() * 94}%`;
  flor.style.top = `${3 + Math.random() * 91}%`;
  flor.style.setProperty("--tamano", `${19 + Math.random() * 18}px`);
  flor.style.setProperty("--duracion", `${3 + Math.random() * 4}s`);
  flor.style.setProperty("--retraso", `${-Math.random() * 4}s`);
  flor.setAttribute("aria-label", "Abrir dedicatoria");

  flor.addEventListener("click", mostrarDedicatoria);
  flores.appendChild(flor);
}

for (let i = 0; i < 24; i++) {
  const petalo = document.createElement("span");
  petalo.className = "petalo";
  petalo.textContent = Math.random() > .25 ? "🌼" : "💛";
  petalo.style.left = `${Math.random() * 100}%`;
  petalo.style.fontSize = `${12 + Math.random() * 14}px`;
  petalo.style.setProperty("--duracion", `${7 + Math.random() * 9}s`);
  petalo.style.setProperty("--retraso", `${-Math.random() * 12}s`);
  petalos.appendChild(petalo);
}

function cerrarModal() {
  modal.classList.remove("mostrar");
}

cerrar.addEventListener("click", cerrarModal);

modal.addEventListener("click", (evento) => {
  if (evento.target === modal) cerrarModal();
});

document.addEventListener("keydown", (evento) => {
  if (evento.key === "Escape") cerrarModal();
});
